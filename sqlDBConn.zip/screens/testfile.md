import React, { useState, useEffect } from 'react';
import { Button, View, Platform, StyleSheet, Text, TouchableOpacity, ScrollView} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as SecureStore from 'expo-secure-store';
import { TextInput } from 'react-native-paper';
import DateTimePicker from '@react-native-community/datetimepicker';

export function SelectDocumentsScreen() {
  const [image, setImage] = useState(null);
  const [date, setDate] = useState(new Date());
  const [mode, setMode] = useState('date');
  const [show, setShow] = useState(false);
  const [fDate, setfDate] = useState();
  const [tDate, settDate] = useState();
  const [fTime, setfTime] = useState();
  const [tTime, setttime] = useState();
  const [dateType, setType] = useState();

  const FromonChange = (event, selectedDate) => {
    const currentDate = selectedDate || date;
    setShow(Platform.OS === 'ios');
    setDate(currentDate);

    let tempDate = new Date(currentDate);
    let fDate = tempDate.getFullYear() + '-' + (tempDate.getMonth() + 1) + '-' + tempDate.getDate();
    let fTime = tempDate.getHours() + ':' + tempDate.getMinutes() + ':' +"00"

    if(dateType == 'fDate'){
      setfDate(fDate);
    }else if(dateType == 'tDate'){
      settDate(fDate);
    }else if(dateType == 'fTime'){
      setfTime(fTime);
    }else if(dateType == 'tTime'){
      setttime(fTime);
    }
  };

  const showMode = (currentMode, timeType) => {
    setShow(true);
    setMode(currentMode);
    setType(timeType);
  };
  useEffect(() => {
    (async () => {
      if (Platform.OS !== 'web') {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
          alert('Sorry, we need camera roll permissions to make this work!');
        }
      }
    })();
  }, []);

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    console.log(result);

    if (!result.cancelled) {
      setImage(result.uri);
    }
  };

  const uploadImage = async (imageurl) => {
    const userId = await SecureStore.getItemAsync("userTb");
    const comId = await SecureStore.getItemAsync("comId");
    var RandomNumber = Math.floor(Math.random() * 1000) + 1 ;

    var imageNm = userId+"_"+comId+"_"+RandomNumber+".png"

    fetch('http://192.168.8.191:1950/SelectedDocuments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          user: {
            imageNm: imageNm,
            userId: userId,
            comId: comId
          }
      })

      })
      .then(response => response.json())
      .then((json) => {
        let base_url = 'http://192.168.8.191/ServerUploadfile/index.php';
        let uploadData = new FormData();
        uploadData.append('submit', 'ok');

        uploadData.append('file', {type:"image/jpeg", uri: imageurl, name:imageNm})

        fetch(base_url,{
          method:'post',
          headers: {
            'Content-Type': 'multipart/form-data',
          },
          body:uploadData
        }).then(res => res.text())
        .then(response => {
          console.log(response);
          console.log("done");
        })
      })
      .catch((error) => console.error(error))
  }

    return (
      <ScrollView style={styles.container}>
        <View style={styles.pickImageBtn}>
          <Button title="Pick an image" onPress={pickImage} />
          <Button title="upload" style={styles.uploadBtnStyle} onPress={()=>uploadImage(image)} />
        </View>
        <View style={styles.imageDescriptionRow}>
          <Text style={styles.imageDescriptionText}>Image Description : </Text>
          <TextInput style={styles.inputcountry} multiline label='' mode='outlined'/>
        </View>
        <View style={styles.datePeriodTextStyle}>
          <Text style={styles.datePeriodText}>Date Period</Text>
        </View>
      <View style={{flexDirection:'row', margin: 20, alignItems: 'center'}}>
        {/* <Text style={{marginTop: 15}}>From Date :   </Text> */}
        <TouchableOpacity onPress={() => showMode('date', 'fDate')}>
          <View style={styles.inputdate}>
            <Text style={styles.inputdatedata}>{fDate}</Text>
          </View>
        </TouchableOpacity>
        <View style={{left: 20}}>
        <TouchableOpacity onPress={() => showMode('date', 'tDate')}>
          <View style={styles.inputdate}>
            <Text style={styles.inputdatedata}>{tDate}</Text>
          </View>
        </TouchableOpacity>
        </View>
      </View>
      <View style={{flexDirection: 'row', margin: 20}}>
        <Text style={{marginTop: 15}}>From Time :   </Text>
        <TouchableOpacity onPress={() => showMode('time', 'fTime')}>
          <View style={styles.inputdate}>
            <Text style={styles.inputdatedata}>{fTime}</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={{flexDirection: 'row', margin: 20}}>
        <Text style={{marginTop: 15}}>To Time :        </Text>
        <TouchableOpacity onPress={() => showMode('time', 'tTime')}>
          <View style={styles.inputdate}>
            <Text style={styles.inputdatedata}>{tTime}</Text>
          </View>
        </TouchableOpacity>
      </View>
      {show && (<DateTimePicker testID="dateTimePicker" value={date} mode={mode} is24Hour={true} display="default" onChange={FromonChange}/>)}
    <View style={styles.container}>
    </View>
    </ScrollView>
    )
}

const styles = StyleSheet.create({
  container: {
      flex: 1,
      backgroundColor: 'white',
  },
  companyLogoTextStyle: {
      alignSelf: 'center',
      fontSize: 23,
      fontWeight: '400',
  },
  viewAfterInnerViewStyle: {
      alignSelf: 'center',
  },
  pickImageBtn: {
      paddingVertical: 20,
      height: 80,
      alignSelf: 'center',
      flexDirection: "row",
  },
  uploadImageBtn:{
      marginTop: 20,
      paddingVertical: 10,
      height: 50,
      alignSelf: 'center',
  },
  additionalOptionsStyle: {
      marginTop: 20,
      margin: 20,
  },
  additionOptionsText: {
      fontSize: 23,
      fontWeight: 'bold',
  },
  imageDescriptionRow: {
      margin: 10,
  },
  imageDescriptionText: {
      fontSize: 15
  },
  inputcountry: {
      height: 100,
      backgroundColor: 'white',
  },
  showDateText: {
      fontSize: 18,
      fontWeight: '500',
      marginTop: 5,
  },
  fromTimeDateStyle: {
      marginTop: 10,
      flexDirection: 'row',
  },
  timePickerStyle: {
      marginTop: 20
  },
nextButtonBackgroundView: {
    backgroundColor: 'yellow',
    borderRadius: 150,
    width: 60,
    height: 60,
    alignSelf: 'center',
    marginTop: 20
},
nextButton: {
    width: 30,
    height: 30,
    alignSelf: 'center',
    marginTop: 15
},
inputdate: {
    backgroundColor: "white",
    borderWidth: 1,
    height: 50,
    borderRadius: 5
},
inputdatedata: {
    alignSelf: 'center',
    width: 150,
    marginTop: 5,
},
datePeriodTextStyle: {
  margin: 20,
},
datePeriodText: {
  fontSize: 23,
  fontWeight: "bold",
},
});

export default SelectDocumentsScreen

